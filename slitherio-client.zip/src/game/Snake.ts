module game {
	export class Snake {

		private body : any[];
		private size : number;
		public speed : number;

		public constructor(body, size, speed) {
			this.body = body;
			this.size = size;
			this.speed = speed;
		}

		public Dead()
		{

		}

		public SetSpeed()
		{

		}



	}
}