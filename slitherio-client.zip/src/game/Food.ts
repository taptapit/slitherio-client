module game {
	export class Food {
		public x : number;
		public y : number;

		public constructor() {
		}
	}
}