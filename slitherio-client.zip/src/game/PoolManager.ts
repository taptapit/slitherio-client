module game {
	export class PoolManager {
		public constructor() {
		}
	}
}