module game {
	export class Game {
		public constructor() {
		}

		public Send()
		{

		}

		public Recieved()
		{

		}

		public Render()
		{
			
		}

	}
}