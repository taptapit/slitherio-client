module game {
	export class GameNetManager {
		public constructor() {
		}
	}
}